-- phpMyAdmin SQL Dump
-- version 4.8.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 23, 2018 at 03:34 PM
-- Server version: 10.1.32-MariaDB
-- PHP Version: 5.6.36

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `webproj`
--

-- --------------------------------------------------------

--
-- Table structure for table `blog_posts`
--

CREATE TABLE `blog_posts` (
  `id` int(3) NOT NULL,
  `post_title` varchar(50) NOT NULL,
  `content` varchar(200) NOT NULL,
  `author_name` varchar(50) NOT NULL,
  `email` varchar(25) NOT NULL,
  `post_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `blog_posts`
--

INSERT INTO `blog_posts` (`id`, `post_title`, `content`, `author_name`, `email`, `post_date`) VALUES
(1, 'anu', 'asdfqertgewrg', 'asgerg', '', '2012-12-12'),
(2, 'qwe', 'gh', 'reiuh', 'anushreesj@gmail.com', '0000-00-00'),
(3, 'tyu', 'bhioo', 'njooo', 'anushreesj@gmail.com', '2018-12-05'),
(4, 'bhootyu', 'ppllll', 'pllkkk', 'anushreesj@gmail.com', '2015-03-27'),
(5, 'bhootyu', 'ppllll', 'pllkkk', 'anushreesj@gmail.com', '2015-03-27'),
(6, 'bhootyu', 'bhioo', 'reiuh', 'anushreesj@gmail.com', '2018-02-12'),
(7, 'qwe', 'bhioo', 'reiuh', 'anushreesj@gmail.com', '2018-11-13');

-- --------------------------------------------------------

--
-- Table structure for table `bookappoint`
--

CREATE TABLE `bookappoint` (
  `id` int(11) NOT NULL,
  `name` varchar(20) NOT NULL,
  `email` varchar(40) NOT NULL,
  `phone` int(11) NOT NULL,
  `type` varchar(20) NOT NULL,
  `date` date NOT NULL,
  `time` varchar(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bookappoint`
--

INSERT INTO `bookappoint` (`id`, `name`, `email`, `phone`, `type`, `date`, `time`) VALUES
(5, 'Anushree S J', 'anushreesj@gmail.com', 2147483647, 'onph', '2018-11-29', '05:3'),
(6, 'Bhoomika', 'bhoomika@gmail.com', 85222, 'onph', '2018-11-30', '06:4'),
(7, 'Anushree S J', 'anushreesj@gmail.com', 2147483647, 'onph', '2018-11-30', '06:45');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `email` varchar(40) NOT NULL,
  `password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`email`, `password`) VALUES
('anushreesj@gmail.com', 'jhg'),
('anushreesj@gmail.com', 'opo'),
('anushreesj@gmail.com', 'iop'),
('anushreesj@gmail.com', 'wee');

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

CREATE TABLE `register` (
  `id` int(11) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  `gender` char(1) NOT NULL,
  `email` varchar(40) NOT NULL,
  `phone` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `register`
--

INSERT INTO `register` (`id`, `username`, `password`, `gender`, `email`, `phone`) VALUES
(7, 'Anushree', 'jhg', 'f', 'anushreesj@gmail.com', 5656),
(8, 'Bhoomika', 'adcaf', 'f', 'bhoomika@gmail.com', 885522),
(9, 'mermi', 'mermi', 'f', 'mermi@mermi.com', 1234567899);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `blog_posts`
--
ALTER TABLE `blog_posts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bookappoint`
--
ALTER TABLE `bookappoint`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `register`
--
ALTER TABLE `register`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `blog_posts`
--
ALTER TABLE `blog_posts`
  MODIFY `id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `bookappoint`
--
ALTER TABLE `bookappoint`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `register`
--
ALTER TABLE `register`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
