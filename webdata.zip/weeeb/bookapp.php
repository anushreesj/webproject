<?php
$name = $_POST['name'];
$phone= $_POST['phone'];
$email = $_POST['email'];
$type = $_POST['type'];
$date = $_POST['date'];
$time = $_POST['time'];
if (!empty($name) ||!empty($phone) || !empty($email) || !empty($type) ||!empty($date) || !empty($time)) {
 $host = "localhost";
    $dbUsername = "root";
    $dbPassword = "admin";
    $dbname = "webproj";
    //create connection
    $conn = new mysqli($host, $dbUsername, $dbPassword, $dbname);
    if (mysqli_connect_error()) {
     die('Connect Error('. mysqli_connect_errno().')'. mysqli_connect_error());
    } else {
     $SELECT = "SELECT email From register Where email = ? Limit 1";
     $INSERT = "INSERT Into bookappoint (name,email,phone,type,date,time) values(?, ?, ?, ?, ?, ?)";
     //Prepare statement
     $stmt = $conn->prepare($SELECT);
     $stmt->bind_param("s", $email);
     $stmt->execute();
     $stmt->bind_result($email);
     $stmt->store_result();
     $rnum = $stmt->num_rows;
     if ($rnum!=0) {
      $stmt->close();
      $stmt = $conn->prepare($INSERT);
      $stmt->bind_param("ssisss", $name, $email,$phone, $type, $date, $time);
      $stmt->execute();
      #$link="htt.html";
	  #echo '<a href="event.html">Login</a>';
	  echo "Succsessfully booked an appointment";
     } else {
       echo '<a href="newone.html">Register</a>';
     }
     $stmt->close();
     $conn->close();
    }
} else {
 echo "All field are required";
 die();
}
?>