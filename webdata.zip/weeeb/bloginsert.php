<?php
$post_title = $_POST['post_title'];
$content= $_POST['content'];
$author_name = $_POST['author_name'];
$email = $_POST['email'];
$post_date = $_POST['post_date'];

if (!empty($post_title) ||!empty($content) || !empty($author_name) || !empty($email) ||!empty($post_date)) {
 $host = "localhost";
    $dbUsername = "root";
    $dbPassword = "admin";
    $dbname = "webproj";
    //create connection
    $conn = new mysqli($host, $dbUsername, $dbPassword, $dbname);
    if (mysqli_connect_error()) {
     die('Connect Error('. mysqli_connect_errno().')'. mysqli_connect_error());
    } else {
     $SELECT = "SELECT email From register Where email = ? Limit 1";
	
     $INSERT = "INSERT Into blog_posts (post_title,content,author_name,email,post_date) values(?, ?, ?, ?, ?)";
     //Prepare statement
     $stmt = $conn->prepare($SELECT);
     $stmt->bind_param("s", $email);
     $stmt->execute();
     $stmt->bind_result($email);
     $stmt->store_result();
     $rnum = $stmt->num_rows;
     if ($rnum!=0) {
      $stmt->close();
      $stmt = $conn->prepare($INSERT);
      $stmt->bind_param("sssss", $post_title, $content,$author_name, $email, $post_date);
      $stmt->execute();
      #$link="htt.html";
	  echo '<a href="blog_view.php"></a>';
	               
	 
	  
     } else {
      echo "try again in some time";
     }
     $stmt->close();
	
     $conn->close();
    }
} else {
 echo "All field are required";
 die();
}
?>