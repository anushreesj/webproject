<?php
$email= $_POST['email'];
$password = $_POST['password'];

if (!empty($email) || !empty($password)) {
    $host = "localhost";
    $dbUsername = "root";
    $dbPassword = "admin";
    $dbname = "webproj";
    //create connection
    $conn = new mysqli($host, $dbUsername, $dbPassword, $dbname);
    if (mysqli_connect_error()) {
     die('Connect Error('. mysqli_connect_errno().')'. mysqli_connect_error());
    } else {
     $SELECT = "SELECT name From register Where name= ? Limit 1";
     //$INSERT = "INSERT Into login (email,password) values(?,?)";
     //Prepare statement
     $stmt = $conn->prepare($SELECT);
     //$stmt->bind_param("s", $password);
     $stmt->execute();
     //$stmt->bind_result($password);
     $stmt->store_result();
     $rnum = $stmt->num_rows;
     if ($rnum>0) {
		 $query=mysql_query("Select password from register where name=?");
		 
      $stmt->close();
      $stmt = $conn->prepare($INSERT);
      $stmt->bind_param("ss",$email,$password);
      $stmt->execute();
      #$link="htt.html";
	  echo '<a href="event.html">Login</a>';
     } else {
      echo "Wrong password ";
     }
     $stmt->close();
     $conn->close();
    }
} else {
 echo "All field are required";
 die();
}
?>