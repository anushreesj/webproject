<html>
<?php 
session_start();
error_reporting(0);
$dbhost = "127.0.0.1";
$dbuser = "root";
$dbpass = "admin";
$dbname = "webproj";
mysql_connect($dbhost,$dbuser,$dbpass) or die('cannot connect to the server'); 
mysql_select_db($dbname) or die('database selection problem');
                   // Check connection



$sql="SELECT * FROM blog_posts";

$result = mysql_query($sql);

while($row = mysql_fetch_array($result)){

?>
<p><?php echo $row['post_title'];?></p>
<p> by <?php echo $row['author_name'];?> on <?php echo $row['post_date'];?></p>
<p><?php echo $row['content']; ?></p>
<?php } ?>

</body>
</html>